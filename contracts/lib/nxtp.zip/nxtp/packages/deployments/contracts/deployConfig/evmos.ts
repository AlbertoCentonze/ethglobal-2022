import { DeployConfig } from "./shared";

export const deployConfig: DeployConfig = {
  XAppConnectionManager: "0x9272c9d5fa902ef3804ec81e0333ae420d57f715",
  TokenRegistry: "0x10b84c73001745d969e7056d7ca474ce1d959fe8",
};
