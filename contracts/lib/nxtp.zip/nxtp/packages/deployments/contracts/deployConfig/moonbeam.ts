import { DeployConfig } from "./shared";

export const deployConfig: DeployConfig = {
  XAppConnectionManager: "0xdb378579c2af11817eea21474a39f95b5b9dfd7e",
  TokenRegistry: "0xa7e4fea3c1468d6c1a3a77e21e6e43daed855c1b",
};
