module.exports = {
    trailingComma: "es5",
    singleQuote: true,
    printWidth: 120,
    bracketSpacing: false,
};

