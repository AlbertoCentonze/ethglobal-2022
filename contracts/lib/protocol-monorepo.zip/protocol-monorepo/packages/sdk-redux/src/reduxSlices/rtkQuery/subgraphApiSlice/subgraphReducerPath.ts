export type SubgraphReducerPath = 'superfluid_subgraph';
