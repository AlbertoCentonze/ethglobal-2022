export type RpcReducerPath = 'superfluid_rpc';
