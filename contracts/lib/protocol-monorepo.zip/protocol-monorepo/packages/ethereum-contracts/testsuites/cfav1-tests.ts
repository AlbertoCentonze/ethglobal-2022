import "../test/contracts/agreements/ConstantFlowAgreementV1-Callback.test";
import "../test/contracts/agreements/ConstantFlowAgreementV1-MFA.test";
import "../test/contracts/agreements/ConstantFlowAgreementV1-Non-Callback.test";
