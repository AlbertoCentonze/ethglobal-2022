import "../test/contracts/tokens/SETH.test";
import "../test/contracts/tokens/PureSuperToken.test";
