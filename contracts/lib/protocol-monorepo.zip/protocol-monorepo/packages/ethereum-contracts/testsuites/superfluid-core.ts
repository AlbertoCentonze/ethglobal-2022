import "../test/contracts/superfluid/Superfluid.test";
import "../test/contracts/superfluid/SuperfluidToken.test";
import "../test/contracts/superfluid/SuperToken.ERC20.test";
import "../test/contracts/superfluid/SuperToken.ERC777.test";
import "../test/contracts/superfluid/SuperToken.NonStandard.test";
import "../test/contracts/superfluid/SuperTokenFactory.test";

import "./cfav1-tests";
import "./idav1-tests";
