import "../test/contracts/agreements/InstantDistributionAgreementV1-Callback.test";
import "../test/contracts/agreements/InstantDistributionAgreementV1-Non-Callback.test";
