// Types
export type FlowActionType =
    | 0 // CREATE
    | 1 // UPDATE
    | 2; // TERMINATE
