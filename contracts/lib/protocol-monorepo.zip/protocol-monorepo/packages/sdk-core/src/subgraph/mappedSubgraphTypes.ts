// TODO(KK): Add comments

export type BlockNumber = number;
export type Timestamp = number;
export type SubgraphId = string;
export type Address = string;
export type BigNumber = string;
