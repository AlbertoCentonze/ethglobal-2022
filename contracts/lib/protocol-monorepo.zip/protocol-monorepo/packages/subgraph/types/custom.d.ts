declare module "@superfluid-finance/ethereum-contracts/scripts/deploy-framework";
declare module "@superfluid-finance/ethereum-contracts/scripts/deploy-test-token";
declare module "@superfluid-finance/ethereum-contracts/scripts/deploy-super-token";
declare module "@superfluid-finance/ethereum-contracts/scripts/gov-set-3Ps-config";
declare module "@superfluid-finance/ethereum-contracts/scripts/deploy-unlisted-pure-super-token";
declare module "@superfluid-finance/ethereum-contracts/scripts/resolver-list-super-token";
declare module "coingecko-api";
declare interface web3 {}
