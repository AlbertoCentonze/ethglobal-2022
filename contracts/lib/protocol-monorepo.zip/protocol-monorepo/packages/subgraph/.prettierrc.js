module.exports = {
    trailingComma: "es5",
    singleQuote: false,
    bracketSpacing: true,
};
