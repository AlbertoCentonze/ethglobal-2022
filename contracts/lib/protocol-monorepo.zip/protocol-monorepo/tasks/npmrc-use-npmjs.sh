cat <<EOF
//registry.npmjs.org/:_authToken=${NPMJS_TOKEN}
EOF
