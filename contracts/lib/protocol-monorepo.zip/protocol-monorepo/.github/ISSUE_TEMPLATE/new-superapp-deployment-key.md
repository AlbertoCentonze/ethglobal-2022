---
name: New Superapp Deployment Key
about: Create ticket to generate a superApp deployment key
title: "[Deployer Whitelisting Request] "
labels: 'Type: Help Me'
assignees: ''

---

**Describe the SuperApp:**

_A clear and concise description of the SuperApp_

**Network will be deployed?:**

**Deployer address:**

**Factory address:**

**Link of repo of the contract to be deployed:**

**Contact info for developer:**

**Notes:**
